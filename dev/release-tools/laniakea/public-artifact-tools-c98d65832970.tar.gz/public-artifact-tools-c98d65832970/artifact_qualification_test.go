package modrt

// External, opt-in artifact smoke fixture. It is NOT part of the product tree.
// No executable is built here. Trade is always a denying fake dependency.
import (
	"bytes"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"debug/buildinfo"
	"debug/elf"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"regexp"
	"runtime"
	"sort"
	"strings"
	"sync"
	"testing"
	"time"

	modcb "github.com/agent-wow/agent-wow/pkg/modules/callback"
	moddisc "github.com/agent-wow/agent-wow/pkg/modules/discovery"
	modrunner "github.com/agent-wow/agent-wow/pkg/modules/runner"
	modsession "github.com/agent-wow/agent-wow/pkg/modules/session"
	modv1 "github.com/agent-wow/agent-wow/pkg/modules/v1"
	"github.com/agent-wow/agent-wow/pkg/opcode"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/health"
	"google.golang.org/grpc/health/grpc_health_v1"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/reflect/protoreflect"
	"google.golang.org/protobuf/types/dynamicpb"
	"google.golang.org/protobuf/types/known/emptypb"
)

var aqNames = []string{"buddy-actions", "buddy-chat", "buddy-inventory", "buddy-loot", "buddy-mail", "buddy-party", "buddy-professions", "buddy-quest-items", "buddy-quests", "buddy-supplies", "buddy-training", "buddy-world"}
var aqHex = regexp.MustCompile(`^[a-f0-9]{64}$`)

type aqArtifact struct {
	Image             string `json:"image"`
	Executable        string `json:"executable"`
	SHA256            string `json:"sha256"`
	ContractDirectory string `json:"contractDirectory"`
}
type aqFile struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
}
type aqBinary struct {
	Executable string `json:"executable"`
	SHA256     string `json:"sha256"`
}
type aqInput struct {
	SourceCommit   string                `json:"sourceCommit"`
	SourceTree     string                `json:"sourceTree"`
	SourceManifest aqFile                `json:"sourceManifest"`
	BuildReceipt   aqFile                `json:"buildReceipt"`
	ImageEvidence  aqFile                `json:"imageEvidence"`
	Core           aqBinary              `json:"core"`
	Helper         aqBinary              `json:"helper"`
	BuildGoImage   string                `json:"buildGoImage"`
	RunDirectory   string                `json:"runDirectory"`
	DockerSocket   string                `json:"dockerSocket"`
	Artifacts      map[string]aqArtifact `json:"artifacts"`
}
type aqChild struct {
	command  *exec.Cmd
	done     chan error
	cid, log string
}
type aqRunner struct {
	root, docker, socket, id string
	artifacts                map[string]aqArtifact
	children                 map[string]*aqChild
	fake                     *grpc.Server
	fakeListener             net.Listener
}

func aqHash(body []byte) string { sum := sha256.Sum256(body); return hex.EncodeToString(sum[:]) }
func aqJSON(path string, value any) error {
	body, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(body, '\n'), 0600)
}
func aqReadRegular(path string, limit int64) ([]byte, error) {
	info, err := os.Lstat(path)
	if err != nil {
		return nil, err
	}
	if !info.Mode().IsRegular() || info.Size() > limit {
		return nil, fmt.Errorf("bounded regular file required: %s", path)
	}
	return os.ReadFile(path)
}
func (r *aqRunner) dockerCommand(ctx context.Context, args ...string) *exec.Cmd {
	all := append([]string{"--host", "unix://" + r.socket, "--config", filepath.Join(r.root, "docker-config")}, args...)
	cmd := exec.CommandContext(ctx, r.docker, all...)
	cmd.Env = []string{"PATH=/usr/bin:/bin:/usr/local/bin", "HOME=" + r.root, "TMPDIR=" + r.root}
	return cmd
}
func (r *aqRunner) Up(ctx context.Context, l modrunner.Launch) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	name := l.Manifest.Name
	if name == "buddy-trade" {
		// Public Trade contract only. Every application call is refused; even
		// BeforeLogout is not represented as a successful private operation.
		listener, err := net.Listen("unix", filepath.Join(l.SocketDir, "module.sock"))
		if err != nil {
			return err
		}
		s := grpc.NewServer(grpc.UnknownServiceHandler(func(_ any, _ grpc.ServerStream) error {
			return status.Error(codes.FailedPrecondition, "artifact fixture: denying FAKE Trade dependency; private binary outside this fixture")
		}))
		h := health.NewServer()
		h.SetServingStatus("", grpc_health_v1.HealthCheckResponse_SERVING)
		grpc_health_v1.RegisterHealthServer(s, h)
		r.fake, r.fakeListener = s, listener
		go s.Serve(listener)
		return nil
	}
	a, ok := r.artifacts[name]
	if !ok {
		return fmt.Errorf("no public executable for %s", name)
	}
	// Launch the ACTUAL maintained public image. Do not override its configured
	// entrypoint or user. No private image or raw-binary wrapper is substituted.
	cid := filepath.Join(r.root, name+".cid")
	args := []string{"run", "--rm", "--pull=never", "--network=none", "--read-only", "--cap-drop=ALL", "--security-opt=no-new-privileges", "--name", "aq-" + r.id + "-" + name, "--label", "agent-wow.artifact-fixture=" + r.id, "--cidfile", cid,
		"--tmpfs", "/tmp:rw,nosuid,noexec,size=32m,mode=1777",
		"--mount", "type=bind,source=" + l.SocketDir + ",target=/run/agent-wow"}
	if name == "buddy-world" {
		args = append(args, "--tmpfs", "/var/lib/buddy-combat-events:rw,nosuid,noexec,size=16m,mode=0700,uid=65532,gid=65532")
	}
	keys := make([]string, 0, len(l.Environment))
	for key := range l.Environment {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	for _, key := range keys {
		args = append(args, "--env", key+"="+l.Environment[key])
	}
	args = append(args, "--env", "BUDDY_INDEPENDENT=true", a.Image)
	logPath := filepath.Join(r.root, name+".log")
	log, err := os.OpenFile(logPath, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	// Start, do not use CommandContext: Close owns container stop and CLI reap.
	cmd := r.dockerCommand(context.Background(), args...)
	cmd.Stdout, cmd.Stderr = log, log
	if err = cmd.Start(); err != nil {
		log.Close()
		return err
	}
	child := &aqChild{command: cmd, done: make(chan error, 1), cid: cid, log: logPath}
	r.children[name] = child
	go func() { err := cmd.Wait(); _ = log.Close(); child.done <- err; close(child.done) }()
	return nil
}
func (r *aqRunner) Down(ctx context.Context, l modrunner.Launch) error {
	if l.Manifest.Name == "buddy-trade" {
		if r.fake != nil {
			r.fake.Stop()
		}
		if r.fakeListener != nil {
			err := r.fakeListener.Close()
			if !errors.Is(err, net.ErrClosed) {
				return err
			}
		}
		return nil
	}
	c := r.children[l.Manifest.Name]
	if c == nil {
		return nil
	}
	var cleanup error
	// Only an ID written by our own run and bearing our random label is removed.
	deadline := time.Now().Add(3 * time.Second)
	for {
		body, err := os.ReadFile(c.cid)
		if err == nil {
			id := strings.TrimSpace(string(body))
			if !aqHex.MatchString(id) {
				cleanup = errors.New("invalid owned container ID")
				break
			}
			out, err := r.dockerCommand(ctx, "inspect", "--format", `{{index .Config.Labels "agent-wow.artifact-fixture"}}`, id).CombinedOutput()
			if err == nil && strings.TrimSpace(string(out)) == r.id {
				_, cleanup = r.dockerCommand(ctx, "rm", "--force", id).CombinedOutput()
			}
			// A completed --rm container may already be absent.
			if err != nil {
				select {
				case <-c.done:
					// CLI completion alone does not establish container absence.
					// A successful read against this same daemon must confirm it.
					remaining, listErr := r.dockerCommand(ctx, "container", "ls", "--all", "--no-trunc", "--filter", "id="+id, "--format", "{{.ID}}").CombinedOutput()
					if listErr == nil && strings.TrimSpace(string(remaining)) == "" {
						return nil
					}
					cleanup = fmt.Errorf("owned container absence not verified after inspection failure: %w", errors.Join(err, listErr))
				default:
					cleanup = fmt.Errorf("owned container inspection failed: %w", err)
				}
			}
			if err == nil && strings.TrimSpace(string(out)) != r.id {
				cleanup = errors.New("container ownership label mismatch; left untouched")
			}
			break
		}
		select {
		case <-c.done:
			cleanup = errors.New("owned CLI exited without CID; container absence not verified")
			break
		default:
		}
		if cleanup != nil {
			break
		}
		if time.Now().After(deadline) {
			cleanup = errors.New("owned CID unavailable; cleanup not verified")
			break
		}
		time.Sleep(25 * time.Millisecond)
	}
	select {
	case <-c.done:
	case <-time.After(3 * time.Second):
		_ = c.command.Process.Kill() // This exact owned Docker CLI only.
		select {
		case <-c.done:
		case <-time.After(3 * time.Second):
			cleanup = errors.Join(cleanup, errors.New("owned CLI not reaped"))
		}
	}
	return cleanup
}

type aqRoute struct {
	Module       string `json:"module"`
	Alias        string `json:"alias"`
	Path         string `json:"path"`
	PublicStatus string `json:"publicStatus"`
	LeafStatus   string `json:"leafStatus"`
	Qualified    bool   `json:"qualified"`
}

func aqStatus(err error) codes.Code {
	var call *CallError
	if errors.As(err, &call) {
		return status.Code(call.Err)
	}
	return status.Code(err)
}
func aqExpected(code codes.Code) bool {
	switch code {
	case codes.OK, codes.InvalidArgument, codes.FailedPrecondition, codes.Aborted, codes.NotFound, codes.AlreadyExists, codes.OutOfRange, codes.PermissionDenied, codes.Unauthenticated, codes.ResourceExhausted:
		return true
	}
	return false
}
func aqIdentity(req *dynamicpb.Message, sid string) {
	fields := req.Descriptor().Fields()
	for _, name := range []protoreflect.Name{"session_id", "self_guid", "character_guid"} {
		if f := fields.ByName(name); f != nil {
			if name == "session_id" && f.Kind() == protoreflect.StringKind {
				req.Set(f, protoreflect.ValueOfString(sid))
			}
			if name != "session_id" && f.Kind() == protoreflect.Uint64Kind {
				req.Set(f, protoreflect.ValueOfUint64(11001))
			}
		}
	}
}

func aqHashFile(path string) (string, error) {
	info, err := os.Lstat(path)
	if err != nil {
		return "", err
	}
	if !info.Mode().IsRegular() {
		return "", errors.New("regular provenance file required")
	}
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err = io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}
func aqEvidence(file aqFile, value any) error {
	if !filepath.IsAbs(file.Path) || !aqHex.MatchString(file.SHA256) {
		return errors.New("frozen external provenance path/hash required")
	}
	body, err := aqReadRegular(file.Path, 32<<20)
	if err != nil {
		return err
	}
	if aqHash(body) != file.SHA256 {
		return errors.New("provenance hash mismatch")
	}
	return json.Unmarshal(body, value)
}
func aqVerifySource(repo string, in aqInput) error {
	var source struct {
		Version                                                                                   int
		SourceRoot, SourceCommit, GitTree, ArchivePath, ArchiveSHA256, HandoffPath, HandoffSHA256 string
		Files                                                                                     map[string]struct{ SHA256, Mode string }
	}
	if err := aqEvidence(in.SourceManifest, &source); err != nil {
		return err
	}
	if source.Version != 1 || source.SourceRoot != repo || source.SourceCommit != in.SourceCommit || source.GitTree != in.SourceTree || len(source.Files) == 0 {
		return errors.New("source handoff/manifest binding mismatch")
	}
	var handoff struct{ Source struct{ Commit, Tree string } }
	if err := aqEvidence(aqFile{source.HandoffPath, source.HandoffSHA256}, &handoff); err != nil {
		return err
	}
	if handoff.Source.Commit != in.SourceCommit || handoff.Source.Tree != in.SourceTree {
		return errors.New("owner-qualified commit/tree association mismatch")
	}
	archive, err := aqHashFile(source.ArchivePath)
	if err != nil {
		return err
	}
	if archive != source.ArchiveSHA256 {
		return errors.New("public archive changed")
	}
	if _, ok := source.Files[".github/workflows/ci.yml"]; !ok {
		return errors.New("complete source workflow provenance required")
	}
	if _, err := os.Lstat(filepath.Join(repo, ".git")); !errors.Is(err, os.ErrNotExist) {
		return errors.New("Gitless archive root required")
	}
	seen := 0
	err = filepath.WalkDir(repo, func(path string, entry fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if entry.Type()&os.ModeSymlink != 0 {
			return errors.New("source symlink refused")
		}
		if entry.IsDir() {
			return nil
		}
		relative, err := filepath.Rel(repo, path)
		if err != nil {
			return err
		}
		relative = filepath.ToSlash(relative)
		expected, ok := source.Files[relative]
		if !ok {
			return fmt.Errorf("unrecorded public source file: %s", relative)
		}
		info, err := entry.Info()
		if err != nil {
			return err
		}
		mode := "100644"
		if info.Mode().Perm()&0111 != 0 {
			mode = "100755"
		}
		actual, err := aqHashFile(path)
		if err != nil {
			return err
		}
		if actual != expected.SHA256 || mode != expected.Mode {
			return fmt.Errorf("public source bytes/mode changed: %s", relative)
		}
		seen++
		return nil
	})
	if err != nil {
		return err
	}
	if seen != len(source.Files) {
		return errors.New("public source file inventory changed")
	}
	return nil
}

func aqInspectELF(binary aqBinary, mainPackage, commit string) (map[string]string, error) {
	actual, err := aqHashFile(binary.Executable)
	if err != nil {
		return nil, err
	}
	if !filepath.IsAbs(binary.Executable) || !aqHex.MatchString(binary.SHA256) || actual != binary.SHA256 {
		return nil, errors.New("built public ELF hash mismatch")
	}
	e, err := elf.Open(binary.Executable)
	if err != nil {
		return nil, err
	}
	machine := e.Machine
	e.Close()
	if machine != elf.EM_X86_64 {
		return nil, errors.New("Linux AMD64 ELF required")
	}
	bi, err := buildinfo.ReadFile(binary.Executable)
	if err != nil {
		return nil, err
	}
	if bi.Path != mainPackage {
		return nil, errors.New("wrong public Go main package")
	}
	evidence := map[string]string{"path": binary.Executable, "sha256": actual, "mainPackage": bi.Path, "goVersion": bi.GoVersion, "embeddedVCS": "absent; external immutable provenance required"}
	cgo := false
	for _, setting := range bi.Settings {
		switch setting.Key {
		case "vcs.revision":
			evidence["embeddedVCS"] = setting.Value
			if setting.Value != commit {
				return nil, errors.New("embedded VCS contradicts frozen source")
			}
		case "vcs.modified":
			if setting.Value != "false" {
				return nil, errors.New("modified VCS artifact refused")
			}
		case "CGO_ENABLED":
			cgo = setting.Value == "0"
		}
	}
	if !cgo {
		return nil, errors.New("maintained CGO_ENABLED=0 build required")
	}
	return evidence, nil
}

type aqImageConfig struct {
	User                 string
	Entrypoint, Cmd, Env []string
	Volumes              map[string]json.RawMessage
	Labels               map[string]string
}
type aqImageRow struct {
	Image, Executable, SHA256, DockerfileSHA256 string
	Config                                      aqImageConfig
	WorldDirectory                              *struct {
		UID, GID, Mode int
		Path           string
	}
}
type aqImages struct {
	Version                   int
	SourceCommit              string
	Images                    map[string]aqImageRow
	CleanupComplete           bool
	ContainersStarted, Builds int
}

func aqConfig(config aqImageConfig) aqImageConfig {
	if config.Entrypoint == nil {
		config.Entrypoint = []string{}
	}
	if config.Cmd == nil {
		config.Cmd = []string{}
	}
	if config.Env == nil {
		config.Env = []string{}
	}
	if config.Volumes == nil {
		config.Volumes = map[string]json.RawMessage{}
	}
	config.Labels = nil
	return config
}

func (r *aqRunner) checkImage(ctx context.Context, name, commit string, row aqImageRow) error {
	a := r.artifacts[name]
	if a.Image != row.Image || a.Executable != row.Executable || a.SHA256 != row.SHA256 {
		return errors.New("same-image extraction binding mismatch")
	}
	body, err := r.dockerCommand(ctx, "image", "inspect", a.Image).Output()
	if err != nil {
		return err
	}
	var images []struct {
		ID           string `json:"Id"`
		OS           string `json:"Os"`
		Architecture string
		Config       aqImageConfig
	}
	if err = json.Unmarshal(body, &images); err != nil {
		return err
	}
	if len(images) != 1 || images[0].ID != a.Image || images[0].OS != "linux" || images[0].Architecture != "amd64" {
		return errors.New("actual image identity/platform mismatch")
	}
	if images[0].Config.Labels["org.opencontainers.image.revision"] != commit || !reflect.DeepEqual(aqConfig(images[0].Config), aqConfig(row.Config)) {
		return errors.New("maintained image config/source revision mismatch")
	}
	if len(images[0].Config.Volumes) != 0 {
		return errors.New("image volumes refused in offline fixture")
	}
	if name == "buddy-world" {
		d := row.WorldDirectory
		if row.Config.User != "65532:65532" || d == nil || d.UID != 65532 || d.GID != 65532 || d.Mode != 0755 || d.Path != "/var/lib/buddy-combat-events" {
			return errors.New("World packaged data directory proof missing")
		}
	}
	return nil
}

func aqDescribe(ctx context.Context, binary string, args []string, home string, expected moddisc.Catalog) error {
	cmd := exec.CommandContext(ctx, binary, args...)
	cmd.Dir = home
	cmd.Env = []string{"PATH=/usr/local/bin:/usr/bin:/bin", "HOME=" + home, "TMPDIR=" + home}
	var output bytes.Buffer
	cmd.Stdout = &output
	cmd.Stderr = &output
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("actual offline metadata command failed: %w", err)
	}
	if output.Len() > 16<<20 {
		return errors.New("offline catalog output bound")
	}
	var actual moddisc.Catalog
	if err := json.Unmarshal(output.Bytes(), &actual); err != nil {
		return err
	}
	if !reflect.DeepEqual(actual, expected) {
		return errors.New("actual Core/helper catalog differs from manifest/FDS registry")
	}
	return nil
}

func TestLaniakeaPublicArtifactsOffline(t *testing.T) {
	if runtime.GOOS != "linux" || runtime.GOARCH != "amd64" {
		t.Fatal("target-local Linux/amd64 fixture only")
	}
	inputPath := os.Getenv("WB_ARTIFACT_QUALIFICATION_INPUT")
	if inputPath == "" {
		t.Fatal("explicit frozen input JSON required")
	}
	body, err := aqReadRegular(inputPath, 1<<20)
	if err != nil {
		t.Fatal(err)
	}
	var in aqInput
	decoder := json.NewDecoder(strings.NewReader(string(body)))
	decoder.DisallowUnknownFields()
	if err = decoder.Decode(&in); err != nil {
		t.Fatal(err)
	}
	if !regexp.MustCompile(`^[a-f0-9]{40}$`).MatchString(in.SourceCommit) || !regexp.MustCompile(`^[a-f0-9]{40}$`).MatchString(in.SourceTree) || !regexp.MustCompile(`^sha256:[a-f0-9]{64}$`).MatchString(in.BuildGoImage) || !filepath.IsAbs(in.RunDirectory) || !filepath.IsAbs(in.DockerSocket) || len(in.Artifacts) != len(aqNames) {
		t.Fatal("frozen source, image ID, fresh absolute run directory, local socket and exact twelve public artifacts required")
	}
	repo, err := filepath.Abs(filepath.Join("..", "..", ".."))
	if err != nil {
		t.Fatal(err)
	}
	if err = aqVerifySource(repo, in); err != nil {
		t.Fatal(err)
	}
	// Validate external output locations before creating any directory. Resolve
	// the existing parent so a symlink cannot turn an external path into source.
	parent, err := filepath.EvalSymlinks(filepath.Dir(in.RunDirectory))
	if err != nil {
		t.Fatal(err)
	}
	if filepath.Join(parent, filepath.Base(in.RunDirectory)) != in.RunDirectory {
		t.Fatal("canonical runDirectory parent required")
	}
	relative, err := filepath.Rel(repo, in.RunDirectory)
	if err != nil || relative == "." || relative != ".." && !strings.HasPrefix(relative, ".."+string(filepath.Separator)) || strings.ContainsAny(in.RunDirectory, ",\r\n") {
		t.Fatal("runDirectory must be outside public source and safe for the exact bind mount")
	}
	outputRoot := filepath.Join(filepath.Dir(in.BuildReceipt.Path), "out", "bin")
	if in.Core.Executable != filepath.Join(outputRoot, "agent-wow") || in.Helper.Executable != filepath.Join(outputRoot, "luapolicy") {
		t.Fatal("Core/helper must be the isolated public build outputs")
	}
	var build struct {
		SourceCommit, SourceTree, SourceManifestSHA256, BuildGoImage, CoreSHA256, HelperSHA256 string
		Images                                                                                 map[string]string
	}
	if err = aqEvidence(in.BuildReceipt, &build); err != nil {
		t.Fatal(err)
	}
	if build.SourceCommit != in.SourceCommit || build.SourceTree != in.SourceTree || build.SourceManifestSHA256 != in.SourceManifest.SHA256 || build.BuildGoImage != in.BuildGoImage || build.CoreSHA256 != in.Core.SHA256 || build.HelperSHA256 != in.Helper.SHA256 || len(build.Images) != len(aqNames) {
		t.Fatal("immutable build/output provenance mismatch")
	}
	var imageEvidence aqImages
	if err = aqEvidence(in.ImageEvidence, &imageEvidence); err != nil {
		t.Fatal(err)
	}
	if imageEvidence.Version != 1 || imageEvidence.SourceCommit != in.SourceCommit || !imageEvidence.CleanupComplete || imageEvidence.ContainersStarted != 0 || imageEvidence.Builds != 0 || len(imageEvidence.Images) != len(aqNames) {
		t.Fatal("same-image extraction provenance incomplete")
	}
	if err = os.Mkdir(in.RunDirectory, 0700); err != nil {
		t.Fatal("runDirectory must not already exist", err)
	}
	if err = os.Mkdir(filepath.Join(in.RunDirectory, "docker-config"), 0700); err != nil {
		t.Fatal(err)
	}
	t.Setenv("TMPDIR", in.RunDirectory)
	random := make([]byte, 12)
	if _, err = rand.Read(random); err != nil {
		t.Fatal(err)
	}
	docker, err := exec.LookPath("docker")
	if err != nil {
		t.Fatal(err)
	}
	r := &aqRunner{root: in.RunDirectory, docker: docker, socket: in.DockerSocket, id: hex.EncodeToString(random), artifacts: in.Artifacts, children: map[string]*aqChild{}}
	graph := filepath.Join(in.RunDirectory, "public-graph")
	if err = os.Mkdir(graph, 0700); err != nil {
		t.Fatal(err)
	}
	contracts := map[string]map[string]string{}
	binaryEvidence := map[string]map[string]string{}
	for name, binary := range map[string]aqBinary{"core": in.Core, "helper": in.Helper} {
		mainPackage := "github.com/agent-wow/agent-wow"
		if name == "helper" {
			mainPackage += "/cmd/luapolicy"
		}
		proof, err := aqInspectELF(binary, mainPackage, in.SourceCommit)
		if err != nil {
			t.Fatalf("%s: %v", name, err)
		}
		binaryEvidence[name] = proof
	}
	all := append(append([]string{}, aqNames...), "buddy-trade")
	for _, name := range all {
		sourceDir := filepath.Join(repo, "modules", name)
		selectedDir := sourceDir
		if name != "buddy-trade" {
			a, ok := in.Artifacts[name]
			if !ok || a.Executable != filepath.Join(filepath.Dir(in.ImageEvidence.Path), name) || a.ContractDirectory != sourceDir || !aqHex.MatchString(a.SHA256) || !regexp.MustCompile(`^sha256:[a-f0-9]{64}$`).MatchString(a.Image) || build.Images[name] != a.Image {
				t.Fatalf("missing explicit public artifact: %s", name)
			}
			evidence, err := aqInspectELF(aqBinary{a.Executable, a.SHA256}, "github.com/agent-wow/agent-wow/modules/"+name+"/cmd", in.SourceCommit)
			if err != nil {
				t.Fatalf("%s: %v", name, err)
			}
			imageRow, present := imageEvidence.Images[name]
			if !present {
				t.Fatal("same-image extraction evidence absent")
			}
			dockerfileHash, err := aqHashFile(filepath.Join(sourceDir, "Dockerfile"))
			if err != nil || dockerfileHash != imageRow.DockerfileSHA256 {
				t.Fatal("maintained Dockerfile provenance mismatch", err)
			}
			inspect, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			err = r.checkImage(inspect, name, in.SourceCommit, imageRow)
			cancel()
			if err != nil {
				t.Fatalf("%s image: %v", name, err)
			}
			evidence["image"] = a.Image
			binaryEvidence[name] = evidence
			selectedDir = a.ContractDirectory
		}
		dst := filepath.Join(graph, name)
		if err = os.Mkdir(dst, 0700); err != nil {
			t.Fatal(err)
		}
		contracts[name] = map[string]string{}
		for _, file := range []string{"module.yaml", "module.pb", "compose.yaml"} {
			selected, err := aqReadRegular(filepath.Join(selectedDir, file), 16<<20)
			if err != nil {
				t.Fatal(err)
			}
			{
				canonical, err := aqReadRegular(filepath.Join(sourceDir, file), 16<<20)
				if err != nil || aqHash(selected) != aqHash(canonical) {
					t.Fatalf("public contract differs from frozen source: %s/%s", name, file)
				}
			}
			contracts[name][file] = aqHash(selected)
			if err = os.WriteFile(filepath.Join(dst, file), selected, 0600); err != nil {
				t.Fatal(err)
			}
		}
	}
	registry, err := moddisc.Load(graph)
	if err != nil {
		t.Fatal(err)
	}
	if len(registry.Order()) != 13 {
		t.Fatal("expected twelve public modules and one explicitly fake Trade dependency")
	}
	// These exact public subcommands load metadata only. Config.Init parses
	// this fresh synthetic file; no auth/session DB, realm or client is opened.
	configPath := filepath.Join(in.RunDirectory, "offline-core.json")
	if err = aqJSON(configPath, map[string]string{"config_dir": filepath.Join(in.RunDirectory, "empty-config"), "data_dir": filepath.Join(in.RunDirectory, "empty-data"), "module_dir": graph, "auth_file_path": filepath.Join(in.RunDirectory, "nonexistent-auth.json"), "realm_file_path": filepath.Join(in.RunDirectory, "nonexistent-realm.json")}); err != nil {
		t.Fatal(err)
	}
	for name, command := range map[string]struct {
		binary string
		args   []string
	}{"core": {in.Core.Executable, []string{"--config", configPath, "module", "describe"}}, "helper": {in.Helper.Executable, []string{"--mode", "describe", "--modules", graph}}} {
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		err = aqDescribe(ctx, command.binary, command.args, in.RunDirectory, registry.Catalog())
		cancel()
		if err != nil {
			t.Fatalf("actual %s metadata: %v", name, err)
		}
	}
	var mu sync.Mutex
	denied := []map[string]any{}
	deny := func(ctx context.Context, op uint32, payload []byte, scope *modv1.TransportScope) error {
		mu.Lock()
		denied = append(denied, map[string]any{"module": modsession.WriteOriginFromContext(ctx).Module, "opcode": op, "bytes": len(payload), "sha256": aqHash(payload), "scoped": scope != nil})
		mu.Unlock()
		return modcb.PacketNotDispatchedError("offline artifact fixture: all game transport denied")
	}
	m := New(registry, r, nil)
	report := map[string]any{"sourceCommit": in.SourceCommit, "sourceTree": in.SourceTree, "sourceManifest": in.SourceManifest, "buildReceipt": in.BuildReceipt, "imageExtractionEvidence": in.ImageEvidence, "coreHelperCatalogQualified": true, "catalogRevision": registry.Catalog().Revision, "fullRuntimeReady": false, "privateTradeBinaryTested": false, "fakeTrade": true, "fakeTradeApplicationCallsDenied": true, "buildGoImage": in.BuildGoImage, "binaryEvidence": binaryEvidence, "publicContracts": contracts, "limitations": []string{"Actual public images and Core/helper metadata smoke, not exhaustive field-level ABI or gameplay proof; absent embedded VCS uses owner-qualified public commit/archive/tree/build provenance.", "Fake Trade is not private Trade ABI, behavior, or runtime proof; the selected mixed graph must separately pass static admission.", "No real Compose launch, navigation asset, persistent volume, character session, accepted booking, actor policy cohort, or game effect is qualified."}}
	defer func() {
		cleanup := m.Close()
		report["cleanupComplete"] = cleanup == nil
		if cleanup != nil {
			report["cleanupError"] = cleanup.Error()
			t.Error(cleanup)
		}
		// Close joins the health workers. A late runtime failure is not an
		// admitted application precondition or a passing artifact smoke probe.
		runtimeErr := m.Err()
		report["publicRuntimeHealthy"] = runtimeErr == nil
		if runtimeErr != nil {
			report["publicRuntimeError"] = runtimeErr.Error()
			report["publicArtifactSmokePassed"] = false
			t.Error(runtimeErr)
		}
		mu.Lock()
		report["deniedPacketAttempts"] = append([]map[string]any{}, denied...)
		mu.Unlock()
		report["testFailed"] = t.Failed()
		if err := aqJSON(filepath.Join(in.RunDirectory, "receipt.json"), report); err != nil {
			t.Error(err)
		}
	}()
	startup, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	err = m.Start(startup, modsession.Session{Identity: modsession.Identity{CharacterGUID: 11001, CharacterName: "ArtifactFixture", RealmID: 1, RealmName: "offline-only"}, Clock: func() uint32 { return 1000 }, SendPacket: func(ctx context.Context, op uint32, p []byte) error { return deny(ctx, op, p, nil) }, SendScopedPacket: deny})
	cancel()
	if err != nil {
		t.Fatal("isolated artifact startup failed", err)
	}
	// One synthetic entry exercises ordinary packet fanout, not an accepted
	// spell/taxi/arrival. No scope is invented and no realm peer exists.
	if err = m.PublishObserved(uint16(opcode.SMSGLoginVerifyWorld), make([]byte, 20), nil); err != nil {
		t.Fatal(err)
	}
	m.mu.Lock()
	idle := m.packetsIdle
	m.mu.Unlock()
	select {
	case <-idle:
	case <-time.After(5 * time.Second):
		t.Fatal("synthetic packet fanout did not drain")
	}
	routes := []aqRoute{}
	qualified := true
	for _, name := range aqNames {
		d, _ := registry.Lookup(name)
		manifest := d.Manifest()
		aliases := make([]string, 0, len(manifest.RPC))
		for alias := range manifest.RPC {
			aliases = append(aliases, alias)
		}
		sort.Strings(aliases)
		for _, alias := range aliases {
			md, _ := d.RPC(alias)
			request := dynamicpb.NewMessage(md.Descriptor().Input())
			aqIdentity(request, filepath.Base(m.dir))
			raw, err := protojson.Marshal(request)
			if err != nil {
				t.Fatal(err)
			}
			ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
			_, publicErr := m.InvokeJSON(ctx, name+"."+alias, raw)
			cancel()
			// InvokeJSON contains legacy compatibility interceptors. The separate
			// leaf call proves the actual executable also exposes the FDS path.
			ctx, cancel = context.WithTimeout(context.Background(), 2*time.Second)
			leafErr := m.instances[name].conn.Invoke(ctx, md.Path(), request, dynamicpb.NewMessage(md.Descriptor().Output()))
			cancel()
			row := aqRoute{Module: name, Alias: alias, Path: md.Path(), PublicStatus: aqStatus(publicErr).String(), LeafStatus: aqStatus(leafErr).String(), Qualified: aqExpected(aqStatus(publicErr)) && aqExpected(aqStatus(leafErr))}
			routes = append(routes, row)
			qualified = qualified && row.Qualified
		}
	}
	report["routes"], report["publicRouteProbePassed"] = routes, qualified
	// Exercise each real public lifecycle path directly. The fake Trade hook
	// deliberately refuses, so whole-graph PrepareLogout is not claimed green.
	lifecycle := map[string]string{}
	for _, name := range aqNames {
		d, _ := registry.Lookup(name)
		if hook, ok := d.BeforeLogout(); ok {
			ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
			err := m.instances[name].conn.Invoke(ctx, hook.Path(), &emptypb.Empty{}, &emptypb.Empty{})
			cancel()
			lifecycle[name] = aqStatus(err).String()
			if !aqExpected(aqStatus(err)) {
				qualified = false
			}
		}
	}
	report["publicLifecycleStatuses"] = lifecycle
	if m.Err() != nil {
		qualified = false
	}
	report["publicArtifactSmokePassed"] = qualified
	m.BeginLogout()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	err = m.PrepareLogout(ctx)
	cancel()
	report["wholeGraphLogoutStatus"] = aqStatus(err).String()
	report["wholeGraphLogoutQualified"] = false
	if !qualified {
		t.Error("one or more actual public routes/lifecycle methods failed qualification; inspect receipt and owned logs")
	}
}
