#!/usr/bin/env python3
"""Freeze already-built PUBLIC image inputs; extract ELF/metadata, never start/build.

Later operator-only step. No private Trade image/command/path is accepted.
"""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import tarfile

NAMES=('buddy-actions','buddy-chat','buddy-inventory','buddy-loot','buddy-mail','buddy-party',
       'buddy-professions','buddy-quest-items','buddy-quests','buddy-supplies','buddy-training','buddy-world')


def require(value,reason):
    if not value:raise RuntimeError(reason)


def sha(body):return hashlib.sha256(body).hexdigest()
def load(path):return json.loads(Path(path).read_text())
def regular(path):
    path=Path(path)
    require(path.is_absolute() and path.resolve(strict=True)==path and not path.is_symlink()
            and path.is_file(),'Canonical absolute regular provenance file required')
    return path
def read_evidence(item):
    path=regular(item['path']);body=path.read_bytes()
    require(len(body)<=32*1024*1024 and sha(body)==item['sha256'],'Bounded frozen evidence hash mismatch')
    return json.loads(body)
def write_new(path,value):
    with Path(path).open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
    Path(path).chmod(0o600)


def final_config(path):
    body=path.read_text();stage=body.rsplit('\nFROM ',1)[-1].splitlines()
    require(stage[0].strip().lower()=='scratch','Only the maintained final scratch stage is supported')
    user,entrypoint='',None
    for line in stage[1:]:
        line=line.strip()
        if line.startswith('USER '):user=line[5:].strip()
        elif line.startswith('ENTRYPOINT '):entrypoint=json.loads(line[11:])
        elif line.startswith(('ENV ','CMD ','VOLUME ')):
            raise RuntimeError('Final-stage Env/Cmd/Volumes require an explicit reviewed extension')
    require(isinstance(entrypoint,list) and len(entrypoint)==1 and isinstance(entrypoint[0],str),
            'Exact maintained entrypoint required')
    return dict(User=user,Entrypoint=entrypoint,Cmd=[],Env=[],Volumes={})


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan',type=Path,required=True)
    parser.add_argument('--extract-dir',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();plan=load(regular(args.plan))
    require(set(plan['artifacts'])==set(NAMES),'Exactly twelve public modules required')
    require(re.fullmatch('sha256:[a-f0-9]{64}',plan['buildGoImage']),'Immutable existing Go image ID required')
    require(Path(plan['dockerSocket']).is_absolute(),'Explicit existing local Docker Unix socket required')
    source=read_evidence(plan['sourceManifest']);source_root=Path(source['sourceRoot']).resolve(strict=True)
    require(str(source_root)==source['sourceRoot'] and source['sourceCommit']==plan['sourceCommit']
            and source['gitTree']==plan['sourceTree'],'Source root/commit/tree mismatch')
    build=read_evidence(plan['buildReceipt'])
    require(build['sourceCommit']==plan['sourceCommit'] and build['sourceTree']==plan['sourceTree']
            and build['sourceManifestSHA256']==plan['sourceManifest']['sha256']
            and build['buildGoImage']==plan['buildGoImage']
            and set(build['images'])==set(NAMES),'Immutable public build receipt mismatch')
    output_root=Path(plan['buildReceipt']['path']).parent/'out'/'bin'
    for name,filename,key in (('core','agent-wow','coreSHA256'),('helper','luapolicy','helperSHA256')):
        item=plan[name]
        require(item['executable']==str(output_root/filename) and item['sha256']==build[key],
                'Core/helper must be the isolated public build outputs')
        require(sha(regular(item['executable']).read_bytes())==item['sha256'],'Built '+name+' hash mismatch')
    for name in NAMES:
        artifact=plan['artifacts'][name]
        require(artifact['contractDirectory']==str(source_root/'modules'/name)
                and artifact['image']==build['images'][name],'Public image/contract binding mismatch')
        dockerfile=source_root/'modules'/name/'Dockerfile'
        require(sha(regular(dockerfile).read_bytes())==source['files']['modules/'+name+'/Dockerfile']['sha256'],
                'Maintained Dockerfile bytes differ from frozen source')
    for output in (args.extract_dir,args.output):
        require(output.is_absolute() and output.parent.resolve(strict=True)==output.parent
                and not output.is_symlink() and not output.resolve().is_relative_to(source_root),
                'Canonical extraction/output paths must remain outside public source')
    require(not args.output.exists(),'Frozen output already exists; left untouched')
    root=args.extract_dir;root.mkdir(mode=0o700,parents=False,exist_ok=False)
    config=root/'docker-config';config.mkdir(mode=0o700)
    owner=secrets.token_hex(12);docker=shutil.which('docker');require(docker,'Existing Docker CLI required')
    env=dict(PATH='/usr/local/bin:/usr/bin:/bin',HOME=str(root),TMPDIR=str(root))
    def call(*words):
        return subprocess.run([docker,'--host','unix://'+plan['dockerSocket'],'--config',str(config),*words],
            env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=30,check=False)
    def checked(*words):
        reply=call(*words);require(reply.returncode==0,'Docker metadata/extraction command failed: '+words[0]);return reply.stdout
    def cleanup(cid):
        require(isinstance(cid,str) and re.fullmatch('[a-f0-9]{64}',cid),
                'Malformed owned extraction CID; absence cannot be verified')
        reply=call('inspect','--format','{{index .Config.Labels "agent-wow.artifact-extract"}}',cid)
        if reply.returncode:
            absent=call('container','ls','--all','--no-trunc','--filter','id='+cid,'--format','{{.ID}}')
            require(absent.returncode==0 and not absent.stdout.strip(),'Owned extraction container absence unverified')
            return
        require(reply.stdout.decode().strip()==owner,'Extraction container label mismatch; left untouched')
        checked('rm','--force',cid)
    evidence=dict(version=1,sourceCommit=plan['sourceCommit'],ownerLabel=owner,images={},cleanupComplete=True,
        containersStarted=0,builds=0,privateTradeTested=False,fullRuntimeReady=False)
    receipt=root/'image-extraction.json'
    try:
        for name in NAMES:
            artifact=plan['artifacts'][name];image=artifact['image']
            require(re.fullmatch('sha256:[a-f0-9]{64}',image),'Immutable public image ID required')
            info=json.loads(checked('image','inspect',image))[0]
            require(info['Id']==image and info['Os']=='linux' and info['Architecture']=='amd64','Image identity/platform mismatch')
            expected=final_config(source_root/'modules'/name/'Dockerfile');actual=info['Config']
            for key in ('User','Entrypoint','Cmd','Env','Volumes'):
                value=actual.get(key) or ({} if key=='Volumes' else '' if key=='User' else [])
                require(value==expected[key],'Maintained image '+key+' mismatch: '+name)
            require(expected['Entrypoint']==['/'+name],'Unexpected public image executable path')
            require((actual.get('Labels') or {}).get('org.opencontainers.image.revision')==plan['sourceCommit'],
                    'Image lacks exact public source revision label')
            if name=='buddy-world':require(expected['User']=='65532:65532','World image ownership contract changed')
            cidfile=root/(name+'.cid');cid=None
            row=dict(image=image,config=expected,dockerfileSHA256=sha((source_root/'modules'/name/'Dockerfile').read_bytes()))
            evidence['images'][name]=row
            try:
                created=call('create','--pull=never','--network=none','--read-only','--name','aq-extract-'+owner+'-'+name,
                    '--label','agent-wow.artifact-extract='+owner,'--cidfile',str(cidfile),image)
                if cidfile.exists():cid=cidfile.read_text().strip()
                require(cid is not None and re.fullmatch('[a-f0-9]{64}',cid),'Owned extraction CID unavailable')
                require(created.returncode==0,'Stopped image container creation failed')
                raw=checked('cp',cid+':/'+name,'-')
                with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as archive:
                    members=archive.getmembers()
                    require(len(members)==1 and members[0].isfile(),'Expected one regular public ELF in image')
                    binary=archive.extractfile(members[0]).read()
                    row['imageExecutableMetadata']=dict(uid=members[0].uid,gid=members[0].gid,mode=members[0].mode&0o7777)
                executable=root/name
                with executable.open('xb') as output:output.write(binary)
                executable.chmod(0o500)
                row.update(executable=str(executable),sha256=sha(binary))
                if name=='buddy-world':
                    raw=checked('cp',cid+':/var/lib/buddy-combat-events','-')
                    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as archive:
                        members=archive.getmembers()
                        require(len(members)==1 and members[0].isdir(),'World packaged journal directory is not empty')
                        directory=members[0];mode=directory.mode&0o7777
                        require((directory.uid,directory.gid,mode)==(65532,65532,0o755),'World packaged journal ownership/mode mismatch')
                        row['worldDirectory']=dict(uid=directory.uid,gid=directory.gid,mode=mode,path='/var/lib/buddy-combat-events')
                artifact.update(executable=row['executable'],sha256=row['sha256'])
            finally:
                if not isinstance(cid,str) or not re.fullmatch('[a-f0-9]{64}',cid):
                    evidence['cleanupComplete']=False
                    raise RuntimeError('Missing/malformed owned CID; extraction cleanup is not verified')
                try:cleanup(cid)
                except BaseException:
                    evidence['cleanupComplete']=False
                    raise
        write_new(receipt,evidence)
        plan['imageEvidence']=dict(path=str(receipt),sha256=sha(receipt.read_bytes()))
        write_new(args.output,plan)
        print(json.dumps(dict(input=str(args.output.absolute()),inputSHA256=sha(args.output.read_bytes()),
            imageEvidence=str(receipt),cleanupComplete=True,containersStarted=0,builds=0,fullRuntimeReady=False)))
    except BaseException as error:
        evidence.update(failed=True,errorType=type(error).__name__)
        if not receipt.exists():write_new(receipt,evidence)
        raise


if __name__=='__main__':main()
