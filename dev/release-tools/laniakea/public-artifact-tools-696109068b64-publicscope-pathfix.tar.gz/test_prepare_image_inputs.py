"""Local real-preparer checks; Docker is entirely fake, no executable is launched.

Only Env comes from the observed c98d metadata summary (evidence SHA256
f27db074687a4f9999191ead027888a086b6ad59ac28cca394686223ce59b0fb).
Other image fields are synthetic fixtures matching PUBLIC Dockerfile contracts.
These tests are not native image/extraction/runtime proof.
"""
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

COMMIT='c98d658329706640bb5e9251f581413c33570512'
TREE='a60e1fb280ac79e27fac458803824baef64c12bd'
OBSERVED_ENV=['PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin']


def load_helper(path):
    spec=importlib.util.spec_from_file_location('preparer_under_test',str(path))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


class PreparerEnvTests(unittest.TestCase):
    def exercise(self,helper,actual_env,expect_failure=False):
        with tempfile.TemporaryDirectory(prefix='wb-preparer-env-',dir='/private/tmp') as tmp:
            root=Path(tmp).resolve();source=root/'source';source.mkdir();out=root/'out'/'bin';out.mkdir(parents=True)
            manifest={'sourceRoot':str(source),'sourceCommit':COMMIT,'gitTree':TREE,'files':{}}
            public=Path(os.environ['WB_ARTIFACT_PUBLIC_SOURCE_ROOT']).resolve(strict=True)
            for name in helper.NAMES:
                relative='modules/'+name+'/Dockerfile';body=(public/relative).read_bytes()
                p=source/relative;p.parent.mkdir(parents=True);p.write_bytes(body)
                manifest['files'][relative]={'sha256':hashlib.sha256(body).hexdigest()}
            def save(name,value):
                p=root/name;p.write_text(json.dumps(value));return {'path':str(p),'sha256':helper.sha(p.read_bytes())}
            binaries={}
            for key,filename in (('core','agent-wow'),('helper','luapolicy')):
                p=out/filename;p.write_bytes(b'SYNTHETIC metadata-guard fixture; not an ELF')
                binaries[key]={'executable':str(p),'sha256':helper.sha(p.read_bytes())}
            source_ref=save('source-manifest.json',manifest)
            images={name:'sha256:'+format(i+1,'064x') for i,name in enumerate(helper.NAMES)}
            build={'sourceCommit':COMMIT,'sourceTree':TREE,'sourceManifestSHA256':source_ref['sha256'],
                   'buildGoImage':'sha256:'+'f'*64,'coreSHA256':binaries['core']['sha256'],
                   'helperSHA256':binaries['helper']['sha256'],'images':images}
            plan={'sourceCommit':COMMIT,'sourceTree':TREE,'sourceManifest':source_ref,
                  'buildReceipt':save('build-receipt.json',build),'buildGoImage':build['buildGoImage'],
                  'dockerSocket':'/var/run/SYNTHETIC-never-opened.sock',**binaries,
                  'artifacts':{name:{'image':image,'contractDirectory':str(source/'modules'/name)} for name,image in images.items()}}
            plan_file=root/'plan.json';plan_file.write_text(json.dumps(plan));calls=[];owned={}
            def tar_payload(name,is_directory=False):
                buf=io.BytesIO()
                with tarfile.open(fileobj=buf,mode='w') as archive:
                    item=tarfile.TarInfo(name);item.mode=0o755
                    if is_directory:
                        item.type=tarfile.DIRTYPE;item.uid=item.gid=65532;archive.addfile(item)
                    else:
                        body=b'SYNTHETIC extracted file; not native proof';item.size=len(body)
                        archive.addfile(item,io.BytesIO(body))
                return buf.getvalue()
            def fake_docker(argv,**kwargs):
                words=argv[argv.index('--config')+2:];calls.append(words)
                result=b''
                if words[:2]==['image','inspect']:
                    image=words[2];name=next(name for name,value in images.items() if value==image)
                    result=json.dumps([{'Id':image,'Os':'linux','Architecture':'amd64','Config':{
                        'User':'65532:65532','Entrypoint':['/'+name],'Cmd':None,'Env':actual_env,
                        'Volumes':None,'Labels':{'org.opencontainers.image.revision':COMMIT}}}]).encode()
                elif words[0]=='create':
                    cid=format(len(owned)+1,'064x');label=words[words.index('--label')+1].split('=',1)[1]
                    owned[cid]=label;Path(words[words.index('--cidfile')+1]).write_text(cid)
                elif words[0]=='cp':
                    path=words[1].split(':',1)[1]
                    result=tar_payload(Path(path).name,path=='/var/lib/buddy-combat-events')
                elif words[0]=='inspect':result=owned[words[-1]].encode()
                elif words[0]=='rm':del owned[words[-1]]
                else:raise AssertionError('No actual Docker command or unreviewed fake path: '+repr(words))
                return subprocess.CompletedProcess(argv,0,stdout=result,stderr=b'')
            argv=['prepare_image_inputs.py','--plan',str(plan_file),'--extract-dir',str(root/'extract'),'--output',str(root/'input.json')]
            with patch.object(sys,'argv',argv),patch.object(helper.shutil,'which',return_value='/FAKE/docker'),patch.object(helper.subprocess,'run',side_effect=fake_docker),contextlib.redirect_stdout(io.StringIO()):
                if expect_failure:
                    with self.assertRaisesRegex(RuntimeError,'Maintained image Env mismatch'):
                        helper.main()
                    self.assertFalse(any(row[0]=='create' for row in calls))
                    self.assertFalse((root/'input.json').exists())
                else:
                    helper.main();result=json.loads((root/'input.json').read_text())
                    proof=json.loads(Path(result['imageEvidence']['path']).read_text())
                    self.assertEqual(len(proof['images']),12)
                    self.assertEqual(sum(row[0]=='create' for row in calls),12)
                    self.assertEqual(sum(row[0]=='rm' for row in calls),12)
                    self.assertFalse(owned)
                    for row in proof['images'].values():self.assertEqual(row['config']['Env'],OBSERVED_ENV)
                    self.assertEqual(proof['containersStarted'],0);self.assertEqual(proof['builds'],0)
                    self.assertFalse(proof['fullRuntimeReady'])
            self.assertFalse(any(row[0] in ('run','start','build') for row in calls))

    def test_old_frozen_helper_rejects_actual_observed_env_before_create(self):
        path=os.environ.get('WB_ARTIFACT_PREPARER_OLD_PATH')
        if path is None:self.skipTest('Pass the preserved old public helper for explicit red evidence')
        self.assertEqual(hashlib.sha256(Path(path).read_bytes()).hexdigest(),
                         '695fde9115dd0d6e29e909fae773c582a1738004a8cd380207bdc359e5292a01')
        self.exercise(load_helper(Path(path)),OBSERVED_ENV,expect_failure=True)

    def test_changed_helper_accepts_all_twelve_observed_env_snapshots_and_retains_env(self):
        self.exercise(load_helper(Path(__file__).with_name('prepare_image_inputs.py')),OBSERVED_ENV)

    def test_extra_changed_missing_or_duplicate_env_still_rejected_before_create(self):
        helper=load_helper(Path(__file__).with_name('prepare_image_inputs.py'))
        for value in (OBSERVED_ENV+['UNEXPECTED=1'],['PATH=/unexpected'],[],OBSERVED_ENV*2):
            with self.subTest(env=value):self.exercise(helper,value,expect_failure=True)

    def test_explicit_final_env_cmd_volume_guards_still_reject(self):
        helper=load_helper(Path(__file__).with_name('prepare_image_inputs.py'))
        with tempfile.TemporaryDirectory(prefix='wb-explicit-config-',dir='/private/tmp') as tmp:
            p=Path(tmp)/'Dockerfile'
            for directive in ('ENV UNEXPECTED=1','CMD ["/unreviewed"]','VOLUME ["/unreviewed"]'):
                p.write_text('FROM golang:1.27.1 AS build\nFROM scratch\nUSER 65532:65532\nENTRYPOINT ["/buddy-actions"]\n'+directive+'\n')
                with self.subTest(directive=directive),self.assertRaisesRegex(RuntimeError,'explicit reviewed extension'):
                    helper.final_config(p)


if __name__=='__main__':unittest.main()
