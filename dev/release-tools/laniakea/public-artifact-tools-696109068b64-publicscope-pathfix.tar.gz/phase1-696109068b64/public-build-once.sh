#!/bin/sh
# ORIGINAL OPERATOR ONLY, after normal scoped action review. No probe/deployment.
set -eu
WB_PATH=/usr/local/bin:/usr/bin:/bin
WB_DOCKER=$(command -v docker)
WB_PYTHON=$(command -v python3)
WB_TIMEOUT=$(command -v timeout)
WB_SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
WB_COMMIT=696109068b64f751bab970dfe134268cc4e6225b
WB_TREE=654c4bd446b163c4c21b84f8586596d41196fdde
WB_HANDOFF_SHA=ab1c49b1bdc9de7701779cc0bc9defa973c0f206e0b53dbb77605422053b432e
WB_STAGED_ARCHIVE=/home/jmax/dev/warcraft_buddy/.artifact-jobs/public-696109068b64-main9a/source/public-source.tar.gz
WB_ARCHIVE_SHA=f5dd2710e781aa16e6534858df6c4a95b35763955dfc9fb2670ea4a40bb18291
WB_GO_IMAGE=sha256:162be5298a40ed317005c8339c6de4d10d3eef336d66dc8e9259b03ab9d3a6d2
: "${WB_ARTIFACT_JOB_ROOT:?Fresh /home/jmax/dev/agent-wow/data/artifact-builds/696109068b64-<unique> required}"
case "$WB_ARTIFACT_JOB_ROOT" in
  /home/jmax/dev/agent-wow/data/artifact-builds/696109068b64-*) ;;
  *) echo 'Dedicated public artifact job root required' >&2; exit 1;;
esac
case "$WB_ARTIFACT_JOB_ROOT" in *[!A-Za-z0-9_./-]*) echo 'Unsafe artifact path' >&2; exit 1;; esac
WB_SUFFIX=${WB_ARTIFACT_JOB_ROOT#/home/jmax/dev/agent-wow/data/artifact-builds/696109068b64-}
case "$WB_SUFFIX" in ''|*[!A-Za-z0-9_-]*) echo 'One nonempty job basename suffix required' >&2; exit 1;; esac
[ "$(id -u)" = 1000 ] || { echo 'Use the maintained UID1000 account/docker group' >&2; exit 1; }
umask 077
"$WB_PYTHON" -B - <<'PY'
from pathlib import Path
import os
p=Path('/home/jmax/dev/agent-wow/data/artifact-builds');ancestor=p
while not ancestor.exists():ancestor=ancestor.parent
assert ancestor.resolve()==ancestor and not p.is_symlink(), 'Non-symlink canonical artifact parent required'
p.mkdir(parents=True,exist_ok=True,mode=0o700)
assert p.resolve()==p and p.stat().st_uid==os.getuid() and not p.stat().st_mode&0o022
PY
mkdir -m 700 "$WB_ARTIFACT_JOB_ROOT" # Fails if any earlier/active job owns this path.
WB_JOB_TAG=${WB_ARTIFACT_JOB_ROOT##*/}
WB_PUBLIC_SOURCE="$WB_ARTIFACT_JOB_ROOT/source"
WB_PUBLIC_OUTPUT="$WB_ARTIFACT_JOB_ROOT/out"
WB_PUBLIC_CACHE="$WB_ARTIFACT_JOB_ROOT/cache"
mkdir -m 700 "$WB_PUBLIC_OUTPUT" "$WB_PUBLIC_CACHE" "$WB_ARTIFACT_JOB_ROOT/docker-config"
exec >"$WB_ARTIFACT_JOB_ROOT/build.log" 2>&1
docker_public() {
  env -i PATH="$WB_PATH" "$WB_DOCKER" --host unix:///var/run/docker.sock --config "$WB_ARTIFACT_JOB_ROOT/docker-config" "$@"
}
docker_bounded() {
  "$WB_TIMEOUT" 15 env -i PATH="$WB_PATH" "$WB_DOCKER" --host unix:///var/run/docker.sock --config "$WB_ARTIFACT_JOB_ROOT/docker-config" "$@"
}
WB_BUILDER_ATTEMPTED=0
WB_BUILDER_PID=
cleanup_builder() {
  WB_CLEANUP_OK=false
  WB_CID=
  if [ "$WB_BUILDER_ATTEMPTED" = 0 ]; then WB_CLEANUP_OK=true
  elif [ -f "$WB_PUBLIC_OUTPUT/core-build.cid" ]; then
    WB_CID=$(cat "$WB_PUBLIC_OUTPUT/core-build.cid")
    case "$WB_CID" in *[!a-f0-9]*) WB_CID=;; esac
    if [ "${#WB_CID}" = 64 ]; then
      if WB_LABEL=$(docker_bounded inspect --format '{{index .Config.Labels "agent-wow.public-build"}}' "$WB_CID"); then
        if [ "$WB_LABEL" = "$WB_JOB_TAG" ]; then docker_bounded rm --force "$WB_CID" || :; fi
      fi
    fi
  fi
  if [ -n "$WB_BUILDER_PID" ]; then kill -TERM "$WB_BUILDER_PID" 2>/dev/null || :; wait "$WB_BUILDER_PID" 2>/dev/null || :; WB_BUILDER_PID=; fi
  if [ "${#WB_CID}" = 64 ]; then
    if WB_REMAINING=$(docker_bounded container ls --all --no-trunc --filter "id=$WB_CID" --format '{{.ID}}'); then
      if [ -z "$WB_REMAINING" ]; then WB_CLEANUP_OK=true; fi
    fi
  fi
  "$WB_PYTHON" -B - "$WB_ARTIFACT_JOB_ROOT/builder-cleanup.json" "$WB_CLEANUP_OK" "$WB_CID" <<'PY'
import json,sys
with open(sys.argv[1],'w') as f:json.dump(dict(cleanupVerified=sys.argv[2]=='true',ownedCID=sys.argv[3],scope='Core/helper builder only; no image/volume/prune cleanup'),f);f.write('\n')
PY
  [ "$WB_CLEANUP_OK" = true ]
}
finish_build() {
  WB_EXIT=$?
  trap - 0 HUP INT TERM
  if ! cleanup_builder; then WB_EXIT=1; fi
  exit "$WB_EXIT"
}
trap finish_build 0
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
docker_public info --format '{{json .ServerVersion}}' >"$WB_ARTIFACT_JOB_ROOT/docker-version.json"
docker_public image inspect "$WB_GO_IMAGE" >"$WB_ARTIFACT_JOB_ROOT/go-image.json"
"$WB_PYTHON" -B - "$WB_ARTIFACT_JOB_ROOT/go-image.json" "$WB_GO_IMAGE" <<'PY'
import json,re,sys
v=json.load(open(sys.argv[1]));assert len(v)==1
v=v[0];assert v['Os']=='linux' and v['Architecture']=='amd64' and re.fullmatch('sha256:[a-f0-9]{64}',v['Id'])
assert v['Id']==sys.argv[2], 'Exact existing Go image required; no pull/fallback'
PY
[ "$(docker_public image inspect --format '{{.Id}}' golang:1.27.1)" = "$WB_GO_IMAGE" ]
"$WB_PYTHON" -B "$WB_SCRIPT_DIR/prepare_overlay.py" --verify-only --extract-source \
  --source-root "$WB_PUBLIC_SOURCE" --source-commit "$WB_COMMIT" --source-tree "$WB_TREE" \
  --archive "$WB_STAGED_ARCHIVE" --archive-sha256 "$WB_ARCHIVE_SHA" \
  --handoff "$WB_SCRIPT_DIR/source-handoff.json" --handoff-sha256 "$WB_HANDOFF_SHA" \
  --manifest "$WB_ARTIFACT_JOB_ROOT/source-manifest.json"
"$WB_PYTHON" -B - "$WB_PUBLIC_SOURCE" <<'PY'
from pathlib import Path
import sys
r=Path(sys.argv[1]);names=('buddy-actions','buddy-chat','buddy-inventory','buddy-loot','buddy-mail','buddy-party','buddy-professions','buddy-quest-items','buddy-quests','buddy-supplies','buddy-training','buddy-world')
for name in names:
    bases=[line.split()[1] for line in (r/'modules'/name/'Dockerfile').read_text().splitlines() if line.startswith('FROM ')]
    assert bases==['golang:1.27.1','scratch'], 'Unreviewed base prerequisite: '+name
PY
cp "$WB_SCRIPT_DIR/build-public.sh" "$WB_PUBLIC_OUTPUT/build-public.sh"
WB_BUILDER_ATTEMPTED=1
env -i PATH="$WB_PATH" "$WB_DOCKER" --host unix:///var/run/docker.sock --config "$WB_ARTIFACT_JOB_ROOT/docker-config" \
  run --rm --pull=never --platform linux/amd64 --user 1000:1000 \
  --label "agent-wow.public-build=$WB_JOB_TAG" --cidfile "$WB_PUBLIC_OUTPUT/core-build.cid" \
  --mount "type=bind,src=$WB_PUBLIC_SOURCE,dst=/src,readonly" \
  --mount "type=bind,src=$WB_PUBLIC_OUTPUT,dst=/out" \
  --mount "type=bind,src=$WB_PUBLIC_CACHE,dst=/cache" \
  -e GOPATH=/cache/gopath -e GOMODCACHE=/cache/gomod -e GOCACHE=/cache/build \
  -w /src "$WB_GO_IMAGE" sh -eu -c 'go version; sh -eu /out/build-public.sh; go version -m /out/bin/agent-wow /out/bin/luapolicy' &
WB_BUILDER_PID=$!
wait "$WB_BUILDER_PID"
WB_BUILDER_PID=
cleanup_builder
for WB_MODULE in buddy-actions buddy-chat buddy-inventory buddy-loot buddy-mail buddy-party buddy-professions buddy-quest-items buddy-quests buddy-supplies buddy-training buddy-world; do
  [ "$(docker_public image inspect --format '{{.Id}}' golang:1.27.1)" = "$WB_GO_IMAGE" ]
  WB_TAG="agent-wow/$WB_MODULE:laniakea-$WB_JOB_TAG"
  docker_public build --pull=false --platform linux/amd64 \
    -f "$WB_PUBLIC_SOURCE/modules/$WB_MODULE/Dockerfile" \
    --label "org.opencontainers.image.revision=$WB_COMMIT" \
    --label "agent-wow.public-build=$WB_JOB_TAG" \
    --iidfile "$WB_PUBLIC_OUTPUT/$WB_MODULE.image-id" -t "$WB_TAG" "$WB_PUBLIC_SOURCE"
  docker_public image inspect "$WB_TAG" >"$WB_PUBLIC_OUTPUT/$WB_MODULE.image.json"
done
"$WB_PYTHON" -B - "$WB_ARTIFACT_JOB_ROOT" "$WB_GO_IMAGE" <<'PY'
import hashlib,json,pathlib,sys
r=pathlib.Path(sys.argv[1]);m=json.loads((r/'source-manifest.json').read_text());o=r/'out'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
images={p.name.removesuffix('.image-id'):p.read_text().strip() for p in o.glob('buddy-*.image-id')}
assert len(images)==12 and 'buddy-trade' not in images
v=dict(sourceCommit=m['sourceCommit'],sourceTree=m['gitTree'],sourceManifestSHA256=sha(r/'source-manifest.json'),
 buildGoImage=sys.argv[2],coreSHA256=sha(o/'bin/agent-wow'),helperSHA256=sha(o/'bin/luapolicy'),images=images,
 archiveSHA256=m['archiveSHA256'],buildLog=str(r/'build.log'),publicModuleBuildCommands=12,coreBuildCommands=1,helperBuildCommands=1,
 moduleELFsRecompiled=False,probeExecuted=False,privateTradeBuilt=False,runtimeReady=False)
with (r/'build-receipt.json').open('x') as f:json.dump(v,f,indent=2);f.write('\n')
print(json.dumps(v))
PY
