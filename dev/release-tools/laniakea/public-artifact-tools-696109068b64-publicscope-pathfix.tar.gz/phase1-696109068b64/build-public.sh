set -eu
mkdir -p /out/bin /out/modules
GOTOOLCHAIN=local CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -buildvcs=false -mod=readonly -trimpath -ldflags="-s -w" -o /out/bin/agent-wow .
GOTOOLCHAIN=local CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -buildvcs=false -mod=readonly -trimpath -ldflags="-s -w" -o /out/bin/luapolicy ./cmd/luapolicy
