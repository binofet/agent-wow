#!/usr/bin/env python3
"""Verify public Gitless archive/tree; write external metadata, never build/run."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile


def require(value, reason):
    if not value:raise SystemExit(reason)


def digest(path):
    value=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):value.update(block)
    return value.hexdigest()


def git_object(kind, body):
    return hashlib.sha1(kind.encode()+b' '+str(len(body)).encode()+b'\0'+body).digest()


def source_files(root):
    result,blobs={},{}
    require(not (root/'.git').exists(),'Gitless public source required')
    for parent,dirs,files in os.walk(root,followlinks=False):
        for name in dirs+files:require(not (Path(parent)/name).is_symlink(),'Source symlink refused')
        for name in files:
            path=Path(parent)/name;info=path.stat()
            require(stat.S_ISREG(info.st_mode),'Regular source files required')
            relative=path.relative_to(root).as_posix();body=path.read_bytes()
            mode='100755' if info.st_mode&0o111 else '100644'
            result[relative]=dict(sha256=hashlib.sha256(body).hexdigest(),mode=mode)
            blobs[relative]=(mode,git_object('blob',body))
    require(result,'Empty public source refused')
    return result,blobs


def tree_id(blobs):
    tree={}
    for path,value in blobs.items():
        node=tree;parts=path.split('/')
        for part in parts[:-1]:node=node.setdefault(part,{})
        node[parts[-1]]=value
    def encode(node):
        body=bytearray()
        for name,value in sorted(node.items(),key=lambda row:(row[0]+'/' if isinstance(row[1],dict) else row[0]).encode()):
            mode,sha=('40000',encode(value)) if isinstance(value,dict) else value
            body.extend(mode.encode()+b' '+name.encode()+b'\0'+sha)
        return git_object('tree',bytes(body))
    return encode(tree).hex()


def archive_files(path):
    result,prefix={},None
    with tarfile.open(path,'r:gz') as archive:
        for entry in archive:
            parts=PurePosixPath(entry.name).parts
            require(parts and not entry.name.startswith('/') and '..' not in parts,'Escaping archive path refused')
            prefix=prefix or parts[0]
            require(parts[0]==prefix,'One codeload root required')
            require(entry.isdir() or entry.isfile(),'Archive links/devices refused')
            if entry.isdir():continue
            require(len(parts)>1,'Archive file at root refused')
            relative='/'.join(parts[1:]);require(relative not in result,'Duplicate archive file refused')
            body=archive.extractfile(entry).read() # Read only; never extract paths.
            result[relative]=dict(sha256=hashlib.sha256(body).hexdigest(),mode='100755' if entry.mode&0o111 else '100644')
    return result


def extract_public(path,root):
    # Validate every member before the first write. No tar path is ever passed
    # to extract/extractall, and links/devices are refused by archive_files.
    archive_files(path)
    root.mkdir(mode=0o755,parents=False,exist_ok=False)
    with tarfile.open(path,'r:gz') as archive:
        for entry in archive:
            if not entry.isfile():continue
            relative=PurePosixPath(entry.name).parts[1:]
            target=root.joinpath(*relative);target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as output:output.write(archive.extractfile(entry).read())
            target.chmod(0o755 if entry.mode&0o111 else 0o644)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('source-root','archive','manifest','handoff'):parser.add_argument('--'+key,type=Path,required=True)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--fixture',type=Path,default=Path(__file__).with_name('artifact_qualification_test.go'))
    parser.add_argument('--verify-only',action='store_true')
    parser.add_argument('--extract-source',action='store_true')
    for key in ('source-commit','source-tree','archive-sha256','handoff-sha256'):parser.add_argument('--'+key,required=True)
    args=parser.parse_args()
    require(all(re.fullmatch('[a-f0-9]{40}',value) for value in (args.source_commit,args.source_tree)),'Qualified immutable commit/tree required')
    require(re.fullmatch('[a-f0-9]{64}',args.archive_sha256),'Frozen public archive hash required')
    require(re.fullmatch('[a-f0-9]{64}',args.handoff_sha256) and digest(args.handoff)==args.handoff_sha256,'Owner-qualified source handoff hash mismatch')
    association=json.loads(args.handoff.read_text()).get('source',{})
    require(association.get('commit')==args.source_commit and association.get('tree')==args.source_tree,
            'Commit/tree must match the independently qualified public-source handoff')
    archive=args.archive.resolve(strict=True)
    require(archive.is_file() and digest(archive)==args.archive_sha256,'Public archive hash mismatch')
    if args.extract_source:extract_public(archive,args.source_root.absolute())
    root=args.source_root.resolve(strict=True)
    files,blobs=source_files(root)
    require(archive_files(archive)==files,'Source differs from complete public archive')
    require(tree_id(blobs)==args.source_tree,'Source file/mode Git tree mismatch')
    require('.github/workflows/ci.yml' in files,'Workflow must remain in complete source provenance')
    require(args.verify_only or args.output is not None,'Overlay output required unless --verify-only')
    for output in (args.manifest,args.output):
        if output is not None:require(not output.resolve().is_relative_to(root),'Outputs must remain external')
    manifest=dict(version=1,sourceRoot=str(root),sourceCommit=args.source_commit,gitTree=args.source_tree,
        archivePath=str(archive),archiveSHA256=args.archive_sha256,
        handoffPath=str(args.handoff.resolve()),handoffSHA256=args.handoff_sha256,files=files)
    with args.manifest.open('x') as stream:json.dump(manifest,stream,sort_keys=True,separators=(',',':'));stream.write('\n')
    if args.verify_only:
        print(json.dumps(dict(sourceCommit=args.source_commit,gitTree=args.source_tree,
            sourceManifest=str(args.manifest.resolve()),sourceManifestSHA256=digest(args.manifest),
            builds=0,containersStarted=0)))
        return
    fixture=args.fixture.resolve(strict=True)
    virtual=root/'pkg/modules/runtime/zz_laniakea_artifact_qualification_external_test.go'
    require(not virtual.exists(),'Overlay target exists; source left untouched')
    with args.output.open('x') as stream:json.dump({'Replace':{str(virtual):str(fixture)}},stream,indent=2);stream.write('\n')
    print(json.dumps(dict(sourceCommit=args.source_commit,gitTree=args.source_tree,
        sourceManifest=str(args.manifest.resolve()),sourceManifestSHA256=digest(args.manifest),
        overlay=str(args.output.resolve()),fixtureSHA256=digest(fixture),executed=False)))


if __name__=='__main__':main()
